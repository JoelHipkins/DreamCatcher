package edu.vt.cs5254.dreamcatcher

import android.os.Bundle
import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import edu.vt.cs5254.dreamcatcher.databinding.FragmentDreamDetailBinding

class DreamDetailFragment : Fragment() {
    private val vm: DreamDetailViewModel by viewModels()
    private var _binding: FragmentDreamDetailBinding? = null
    private val binding get() = checkNotNull(_binding) {"FragmentDreamDetailBinding is null!!"}
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentDreamDetailBinding.inflate(inflater, container, false)
        return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // this is setting listeners (basically onCreate of an Activity)
        updateView()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun updateView(){
        binding.titleText.setText(vm.dream.title)

      val formattedDate = DateFormat.format("'Last updated' yyyy-MM-dd 'at' hh:mm:ss A", vm.dream.lastUpdated)
        binding.lastUpdatedText.text = formattedDate // not propery formatted

        val buttonList = listOf(
            binding.entry0Button,
            binding.entry1Button,
            binding.entry2Button,
            binding.entry3Button,
            binding.entry4Button,
        )

        buttonList.forEach { it.visibility = View.GONE }

        buttonList.zip(vm.dream.entries).forEach { (btn, entry)  ->
            btn.configureForEntry(entry)


        }


        binding.fulfilledCheckbox.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {

                binding.entry3Button.visibility = View.VISIBLE
                binding.entry3Button.text = "Fulfilled"

                binding.deferredCheckbox.isEnabled = false
            } else {

                binding.entry3Button.visibility = View.GONE

                binding.deferredCheckbox.isEnabled = true
            }
        }

        binding.deferredCheckbox.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {

                binding.entry4Button.visibility = View.VISIBLE
                binding.entry4Button.text = "Deferred"

                binding.fulfilledCheckbox.isEnabled = false
            } else {

                binding.entry4Button.visibility = View.GONE

                binding.fulfilledCheckbox.isEnabled = true
            }
        }
    }

//        //update the view from the model
    }

   private fun Button.configureForEntry(entry: DreamEntry) {
        text = entry.kind.toString()
        visibility = View.VISIBLE
        when(entry.kind) {
            DreamEntryKind.REFLECTION -> {
                text = entry.text
                isAllCaps = false
                setBackgroundWithContrastingText("cyan")

            }
            DreamEntryKind.DEFERRED -> {
                setBackgroundWithContrastingText("yellow")

            }

            DreamEntryKind.FULFILLED -> {
                setBackgroundWithContrastingText("violet")


            }

            DreamEntryKind.CONCEIVED -> {
                setBackgroundWithContrastingText("red")

            }

        }



    }

